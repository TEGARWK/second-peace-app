import 'package:secondpeacem/models/product.dart';

final List<Product> dummyProducts = [
  Product(
    name: 'Jaket Denim',
    price: 120000,
    imageUrl: 'assets/baju.jpg',
    size: 'L',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Sepatu Sneakers',
    price: 250000,
    imageUrl: 'assets/sepatu.jpg',
    size: '42',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Topi Trucker',
    price: 80000,
    imageUrl: 'assets/aksesoris.jpg',
    size: 'All Size',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Jaket Denim',
    price: 120000,
    imageUrl: 'assets/baju.jpg',
    size: 'L',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Sepatu Sneakers',
    price: 250000,
    imageUrl: 'assets/sepatu.jpg',
    size: '42',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Topi Trucker',
    price: 80000,
    imageUrl: 'assets/aksesoris.jpg',
    size: 'All Size',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Jaket Denim',
    price: 120000,
    imageUrl: 'assets/baju.jpg',
    size: 'L',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Sepatu Sneakers',
    price: 250000,
    imageUrl: 'assets/sepatu.jpg',
    size: '42',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Topi Trucker',
    price: 80000,
    imageUrl: 'assets/aksesoris.jpg',
    size: 'All Size',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Jaket Denim',
    price: 120000,
    imageUrl: 'assets/baju.jpg',
    size: 'L',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Sepatu Sneakers',
    price: 250000,
    imageUrl: 'assets/sepatu.jpg',
    size: '42',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
  Product(
    name: 'Topi Trucker',
    price: 80000,
    imageUrl: 'assets/aksesoris.jpg',
    size: 'All Size',
    description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
];
