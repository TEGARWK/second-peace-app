import 'package:flutter/material.dart';
import '../services/cart_service.dart';

class CartProvider extends ChangeNotifier {
  CartService cartService;

  CartProvider({required this.cartService});

  set setCartService(CartService newService) {
    cartService = newService;
    notifyListeners();
  }

  List<Map<String, dynamic>> _cartItems = [];

  List<Map<String, dynamic>> get items => _cartItems;

  int get totalItems => _cartItems.length;

  bool get isAllChecked =>
      _cartItems.isNotEmpty &&
      _cartItems.every((item) => item['selected'] == true);

  /// 🔄 Ambil data keranjang dari backend
  Future<void> fetchCart(int userId) async {
    if (userId == null) return;

    try {
      final data = await cartService.fetchCartItems(userId);

      _cartItems =
          data.map<Map<String, dynamic>>((item) {
            final produk = item['produk'];
            final isSold = produk == null || (produk['stok'] ?? 0) < 1;

            return {...item, 'selected': !isSold, 'is_sold': isSold};
          }).toList();

      notifyListeners();
    } catch (e) {
      debugPrint('❌ Error fetchCart: $e');
    }
  }

  Future<void> addItem({
    required int userId,
    required int produkId,
    required int jumlah,
    required String name,
    required String imageUrl,
    required int harga,
  }) async {
    try {
      final alreadyInCart = _cartItems.any((item) {
        final itemProduk = item['produk'];
        return itemProduk != null && itemProduk['id_produk'] == produkId;
      });

      if (alreadyInCart) throw Exception('Produk ini sudah ada di keranjang');

      await cartService.addToCart(
        userId: userId,
        produkId: produkId,
        jumlah: jumlah,
      );
      await fetchCart(userId);
    } catch (e) {
      debugPrint('❌ Error addItem: $e');
      rethrow;
    }
  }

  Future<void> removeItem(int keranjangId, int userId) async {
    try {
      await cartService.removeFromCart(keranjangId);
      await fetchCart(userId);
    } catch (e) {
      debugPrint('❌ Error removeItem: $e');
    }
  }

  void toggleSelect(int index) {
    if (_cartItems[index]['is_sold'] == true) return;
    _cartItems[index]['selected'] = !_cartItems[index]['selected'];
    notifyListeners();
  }

  void toggleSelectAll(bool value) {
    for (var item in _cartItems) {
      if (item['is_sold'] != true) {
        item['selected'] = value;
      }
    }
    notifyListeners();
  }

  int get getTotalPrice {
    return _cartItems.fold<int>(0, (sum, item) {
      final harga = (item['produk']?['harga'] ?? 0) as num;
      final qty = (item['jumlah'] ?? 1) as num;
      return item['selected'] == true ? sum + (harga * qty).toInt() : sum;
    });
  }

  int getTotalQty() {
    return _cartItems.fold<int>(0, (sum, item) {
      final qty = (item['jumlah'] ?? 1) as int;
      return item['selected'] == true ? sum + qty : sum;
    });
  }

  void updateToken(String newToken) {
    cartService = CartService(baseUrl: cartService.baseUrl, token: newToken);
    notifyListeners();
  }
}
